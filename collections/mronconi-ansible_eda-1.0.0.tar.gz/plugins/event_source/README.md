
# EDA Event Source Plugin

Event source plugins describe the source of an event stream.  Event sources are the
main plugin that produces events for EDA.
